import "./App.css";
import Calc from "./components/Calc.js";
function App() {
  return (
    <>
      <Calc />
    </>
  );
}

export default App;

	
